from PIL import Image

from pixelmatch.contrib.PIL import pixelmatch

img_a = Image.open("Rose1.jpg")
img_b = Image.open("Rose2.jpg")
img_diff = Image.new("RGBA", img_a.size)

#  no need to specify dimensions
mismatch = pixelmatch(img_a, img_b, img_diff, includeAA=True)

img_diff.save("Rose_diff_Pixel.png")



